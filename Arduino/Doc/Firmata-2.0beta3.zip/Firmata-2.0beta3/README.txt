
This is the Firmata library for the Arduino and Wiring environments.  For
complete documentation, see the Firmata web page:

http://firmata.org

To install Firmata, unzip the Firmata zip file, then move the included
"Firmata" folder into your Arduino installation.  Do not move the whole
"Pduino-0.4beta2" folder, just the "Firmata" folder.  Here are some typical
locations based on OS:

GNU/Linux: ~/Desktop/arduino-0011/hardware/libraries
Mac OS X:  /Applications/arduino-0011/hardware/libraries
Windows:   C:\Program Files\arduino-0011\hardware\libraries
